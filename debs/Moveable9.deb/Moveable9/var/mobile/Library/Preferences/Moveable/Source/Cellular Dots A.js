(height, signalStrengthRaw, isTintBlack, extraOption, color)
{
	var lowerLimit = -130, upperLimit = -80;
	var range = Math.abs(lowerLimit - upperLimit);

	var percentage = 0;
	if (signalStrengthRaw <= lowerLimit) {
		percentage = 0;
	} else if (signalStrengthRaw >= upperLimit) {
		percentage = 100;
	} else {
		percentage = Math.round(100 * (signalStrengthRaw - lowerLimit) / range);
	}

	var
		canvas = document.createElement("canvas"),
		context = canvas.getContext("2d"),
		dotCount = 5,
		spacer = Math.round(height * 0.075),
		dotWidth = Math.floor(height * 0.275),
		dotHeight = dotWidth,
		lineWidth = 1,
		mainColor = "rgb(" + color.join() + ")",
		canvasHeight = height,
		canvasWidth = dotWidth * dotCount + 4 * spacer;

	canvas.width = canvasWidth;
	canvas.height = canvasHeight;

	context.lineWidth = lineWidth;
	context.strokeStyle = mainColor;
	context.fillStyle = mainColor;

	percentPerDot = 100 / dotCount;
	radius = dotWidth / 2.0;
	cy = Math.round((height - dotWidth) / 2.0) + radius;
	radius = radius - lineWidth;

	for (var i = 0; i < dotCount; i++) {
		topLeft = i * spacer + i * dotWidth;
		cx = topLeft + dotWidth / 2.0;

		context.beginPath();
		context.arc(cx, cy, radius, 0, 2 * Math.PI);
		context.stroke();
		context.stroke();

		if (percentage > 20.0 * (i + 1))
			heightLocal = 1;
		else
			heightLocal = (percentage - 20.0 * i) / 20.0;

		if (percentage > ((i + 1) * percentPerDot)) {
			context.fill();
		} else if (percentage > (i * percentPerDot)) {
			fillWidth = 2 * radius * (percentage - (i * percentPerDot)) / percentPerDot;
			context.save();
			context.beginPath();
			context.arc(cx, cy, radius, 0, 2 * Math.PI, false);
			context.clip();
			context.fillRect(cx - radius, cy - radius, fillWidth, radius * 2);
			context.restore();
		}
	}

	return canvas.toDataURL("image/png");
}
